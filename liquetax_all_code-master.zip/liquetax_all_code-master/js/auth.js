/**
 * Authentication System
 * Handles OAuth flows for all social media platforms
 */

class AuthSystem {
    constructor() {
        this.initializeFacebookSDK();
        this.initializeGoogleAPI();
        this.setupEventListeners();
    }

    /**
     * Initialize Facebook SDK
     */
    initializeFacebookSDK() {
        window.fbAsyncInit = function () {
            FB.init({
                appId: '2516243255424873', // Replace with actual App ID
                cookie: true,
                xfbml: true,
                version: 'v18.0'
            });

            FB.AppEvents.logPageView();
            console.log('Facebook SDK initialized');
        };
    }

    /**
     * Initialize Google API
     */
    initializeGoogleAPI() {
        window.gapi = window.gapi || {};
        if (typeof gapi !== 'undefined' && gapi.load) {
            gapi.load('auth2', () => {
                gapi.auth2.init({
                    client_id: 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com'
                }).then(() => {
                    console.log('Google API initialized');
                });
            });
        }
    }

    /**
     * Setup event listeners for social connect buttons
     */
    setupEventListeners() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.bindButtons());
        } else {
            this.bindButtons();
        }
    }

    /**
     * Bind click events to social media buttons
     */
    bindButtons() {
        const platforms = ['facebook', 'google', 'linkedin', 'instagram', 'twitter'];

        platforms.forEach(platform => {
            const button = document.getElementById(`${platform}ConnectBtn`);
            if (button) {
                button.onclick = (e) => {
                    e.preventDefault();
                    this.connectPlatform(platform);
                };
                console.log(`${platform} button connected`);
            }
        });
    }

    /**
     * Connect to social media platform
     */
    async connectPlatform(platform) {
        console.log(`Connecting to ${platform}...`);

        switch (platform) {
            case 'facebook':
                return this.connectFacebook();
            case 'google':
                return this.connectGoogle();
            case 'linkedin':
                return this.connectLinkedIn();
            case 'instagram':
                return this.connectInstagram();
            case 'twitter':
                return this.connectTwitter();
            default:
                console.error(`Unknown platform: ${platform}`);
        }
    }

    /**
     * Facebook OAuth flow
     */
    connectFacebook() {
        return new Promise((resolve, reject) => {
            FB.login((response) => {
                if (response.authResponse) {
                    const accessToken = response.authResponse.accessToken;

                    // Get user info
                    FB.api('/me', { fields: 'name,email,picture' }, (userInfo) => {
                        const connectionData = {
                            platform: 'facebook',
                            accessToken: accessToken,
                            userInfo: userInfo,
                            connectedAt: new Date().toISOString()
                        };

                        // Store connection data
                        localStorage.setItem('facebookConnection', JSON.stringify(connectionData));
                        localStorage.setItem('facebookConnected', 'true');

                        // Update UI
                        this.updateConnectionStatus('facebook', true, userInfo);

                        // Show success message
                        this.showNotification('Successfully connected to Facebook!', 'success');

                        resolve(connectionData);
                    });
                } else {
                    this.showNotification('Facebook connection cancelled', 'warning');
                    reject(new Error('Facebook login cancelled'));
                }
            }, { scope: 'public_profile,email,pages_manage_posts' });
        });
    }

    /**
     * Google OAuth flow
     */
    connectGoogle() {
    const clientId = "57602832522-m8co1bqabgcgui2978geipq5p7slq85s.apps.googleusercontent.com";
    const redirectUri = "https://liquetax-all-code.onrender.com/auth/google/callback"; // ✅ Use Render domain
    const scope = encodeURIComponent("openid profile email");

    // Google OAuth 2.0 endpoint
    const googleUrl = `https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&access_type=offline&prompt=consent`;

    // Open popup
    const popup = window.open(googleUrl, "GoogleAuth", "width=500,height=600,scrollbars=yes,resizable=yes");

    // Check for popup close
    const checkClosed = setInterval(() => {
      try {
        if (!popup || popup.closed) {
          clearInterval(checkClosed);
          alert("Google connection cancelled");
        }
      } catch (e) {
        // Ignore COOP errors
      }
    }, 1000);

    // Listen for message from backend callback
    const messageHandler = (event) => {
      console.log("Received event:", event);

      // Make sure the message is from our Render domain
      if (event.origin !== "https://liquetax-all-code.onrender.com") return;

      if (event.data.type === "GOOGLE_AUTH_SUCCESS") {
        clearInterval(checkClosed);
        window.removeEventListener("message", messageHandler);
        if (popup) popup.close();

        // Save user data
        localStorage.setItem("googleConnection", JSON.stringify(event.data.connectionData));
        localStorage.setItem("googleConnected", "true");

        // Redirect to dashboard
        window.location.href = "/dashboard-new.html";
      }
    };

    window.addEventListener("message", messageHandler);
  }
    // connectGoogle() {
    //     const clientId = "57602832522-m8co1bqabgcgui2978geipq5p7slq85s.apps.googleusercontent.com";
    //     const redirectUri = "http://localhost:3000/auth/google/callback"; // Your backend callback
    //     const scope = encodeURIComponent("openid profile email");

    //     // Google OAuth 2.0 endpoint
    //     const googleUrl = `https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&access_type=offline&prompt=consent`;

    //     // Open popup
    //     const popup = window.open(googleUrl, "GoogleAuth", "width=500,height=600,scrollbars=yes,resizable=yes");

    //     // Check for popup close
    //     const checkClosed = setInterval(() => {
    //         try {
    //             if (!popup || popup.closed) {
    //                 clearInterval(checkClosed);
    //                 this.showNotification("Google connection cancelled", "warning");
    //             }
    //         } catch (e) {
    //             // Ignore COOP errors
    //         }
    //     }, 1000);

    //     // Listen for message from backend callback
    //     const messageHandler = (event) => {
    //         console.log("yaha tak ch===",event)
    //         // Make sure message is from our origin
    //         if (event.origin !== window.location.origin) return;
    //         console.log("event.data.type******************************", event.data.type);

    //         if (event.data.type === "GOOGLE_AUTH_SUCCESS") {
    //             clearInterval(checkClosed);
    //             window.removeEventListener("message", messageHandler);
    //             if (popup) popup.close();

    //             // Store data in localStorage
    //             localStorage.setItem("googleConnection", JSON.stringify(event.data.connectionData));
    //             localStorage.setItem("googleConnected", "true");

    //             // res.cookie("user", JSON.stringify(profile), { httpOnly: false });
    //             // res.cookie("access_token", tokenData.access_token, { httpOnly: false });


    //             // Update UI
    //              // ✅ Update button UI immediately
    //             this.updateConnectionStatus("google", true, event.data.connectionData?.userInfo);
    //             this.showNotification("Successfully connected to Google!!", "success");
                

    //             // Redirect main window to dashboard
    //             window.location.href = "/dashboard-new.html"; // Replace with your actual dashboard route
    //         }
    //     };

    //     window.addEventListener("message", messageHandler);
    // }



    /**
     * LinkedIn OAuth flow (opens popup)
     */
    connectLinkedIn() {
        const clientId = 'YOUR_LINKEDIN_CLIENT_ID';
        const redirectUri = encodeURIComponent(window.location.origin + '/auth/linkedin/callback');
        const scope = encodeURIComponent('r_liteprofile r_emailaddress w_member_social');

        const linkedinUrl = `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${clientId}&redirect_uri=${redirectUri}&scope=${scope}`;

        // Open popup for LinkedIn OAuth
        const popup = window.open(linkedinUrl, 'LinkedInAuth', 'width=500,height=600,scrollbars=yes,resizable=yes');

        // Listen for popup close or message
        const checkClosed = setInterval(() => {
            if (popup.closed) {
                clearInterval(checkClosed);
                this.showNotification('LinkedIn connection cancelled', 'warning');
            }
        }, 1000);

        // Listen for auth success message
        window.addEventListener('message', (event) => {
            if (event.data.type === 'LINKEDIN_AUTH_SUCCESS') {
                clearInterval(checkClosed);
                popup.close();

                // Store connection data
                localStorage.setItem('linkedinConnection', JSON.stringify(event.data.connectionData));
                localStorage.setItem('linkedinConnected', 'true');

                // Update UI
                this.updateConnectionStatus('linkedin', true, event.data.connectionData.userInfo);
                this.showNotification('Successfully connected to LinkedIn!', 'success');
            }
        });
    }

    /**
     * Instagram OAuth flow
     */
    connectInstagram() {
        const clientId = 'YOUR_INSTAGRAM_CLIENT_ID';
        const redirectUri = encodeURIComponent(window.location.origin + '/auth/instagram/callback');
        const scope = encodeURIComponent('user_profile,user_media');

        const instagramUrl = `https://api.instagram.com/oauth/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&scope=${scope}&response_type=code`;

        // Open popup for Instagram OAuth
        const popup = window.open(instagramUrl, 'InstagramAuth', 'width=500,height=600,scrollbars=yes,resizable=yes');

        // Similar popup handling as LinkedIn
        this.handleOAuthPopup(popup, 'instagram', 'Instagram');
    }

    /**
     * Twitter OAuth flow
     */
    connectTwitter() {
        // Twitter OAuth 2.0 requires server-side implementation
        // Redirect to server endpoint that handles Twitter OAuth
        window.location.href = '/auth/twitter';
    }

    /**
     * Handle OAuth popup for Instagram and LinkedIn
     */
    handleOAuthPopup(popup, platform, platformName) {
        const checkClosed = setInterval(() => {
            if (popup.closed) {
                clearInterval(checkClosed);
                this.showNotification(`${platformName} connection cancelled`, 'warning');
            }
        }, 1000);

        window.addEventListener('message', (event) => {
            if (event.data.type === `${platform.toUpperCase()}_AUTH_SUCCESS`) {
                clearInterval(checkClosed);
                popup.close();

                localStorage.setItem(`${platform}Connection`, JSON.stringify(event.data.connectionData));
                localStorage.setItem(`${platform}Connected`, 'true');

                this.updateConnectionStatus(platform, true, event.data.connectionData.userInfo);
                this.showNotification(`Successfully connected to ${platformName}!`, 'success');
            }
        });
    }

    /**
     * Update connection status in UI
     */
    updateConnectionStatus(platform, connected, userInfo = null) {
    const platformElement = document.querySelector(`[data-platform="${platform}"]`);
    if (!platformElement) {
        console.warn(`⚠️ No element found for platform: ${platform}`);
        return;
    }

    const badge = platformElement.querySelector('.badge');
    const button = platformElement.querySelector('.btn');

    // ✅ Update badge
    console.log("badge*****",badge);
    if (badge) {
        badge.textContent = connected ? "Connected" : "Not Connected";
        badge.classList.remove("bg-success", "bg-warning");
        badge.classList.add(connected ? "bg-success" : "bg-warning");
    }

    // ✅ Update button
    console.log("button**",button);
    if (button) {
        if (connected) {
            button.innerHTML = `<i class="fas fa-check me-1"></i> Connected`;
            button.classList.remove("btn-primary");
            button.classList.add("btn-success");
            if (userInfo?.name) {
                button.title = `Connected as ${userInfo.name}`;
            }
        } else {
            button.innerHTML = `<i class="fas fa-link me-1"></i> Connect`;
            button.classList.remove("btn-success");
            button.classList.add("btn-primary");
            button.title = `Connect to ${platform}`;
        }
    }

    // ✅ Update other modules if available
    if (window.socialMedia?.updateAllConnectionStatus) {
        window.socialMedia.updateAllConnectionStatus();
    }
}


    /**
     * Disconnect from platform
     */
    disconnectPlatform(platform) {
        // Remove stored data
        localStorage.removeItem(`${platform}Connection`);
        localStorage.removeItem(`${platform}Connected`);

        // Update UI
        this.updateConnectionStatus(platform, false);

        // Platform-specific logout
        switch (platform) {
            case 'facebook':
                if (typeof FB !== 'undefined') {
                    FB.logout();
                }
                break;
            case 'google':
                if (typeof gapi !== 'undefined' && gapi.auth2) {
                    gapi.auth2.getAuthInstance().signOut();
                }
                break;
        }

        this.showNotification(`Disconnected from ${platform}`, 'info');
    }

    /**
     * Check connection status on page load
     */
    checkConnectionStatus() {
        const platforms = ['facebook', 'google', 'linkedin', 'instagram', 'twitter'];

        platforms.forEach(platform => {
            const connected = localStorage.getItem(`${platform}Connected`) === 'true';
            const connectionData = localStorage.getItem(`${platform}Connection`);

            if (connected && connectionData) {
                const data = JSON.parse(connectionData);
                this.updateConnectionStatus(platform, true, data.userInfo);
            }
        });
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info') {
        // Use existing notification system or create a simple one
        if (typeof showNotification === 'function') {
            showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
            // Fallback to alert for now
            alert(message);
        }
    }
}

// Initialize auth system when DOM is ready
let authSystem;
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        authSystem = new AuthSystem();
        authSystem.checkConnectionStatus();
    });
} else {
    authSystem = new AuthSystem();
    authSystem.checkConnectionStatus();
}

// Export for global access
window.authSystem = authSystem;
