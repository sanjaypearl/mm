# Liquetax Dashboard

A modern, feature-rich dashboard for managing blog content and social media integration for Liquetax.

## Features

- **Blog Management**
  - Create, edit, and delete blog posts
  - Rich text editor with formatting options
  - Featured image upload
  - Category and tag management
  - Draft and scheduled posts
  - Post preview

- **Social Media Integration**
  - Share posts to Twitter, Facebook, and LinkedIn
  - Customize social media messages
  - Schedule social media posts
  - Social media preview

- **Analytics**
  - View traffic statistics
  - Track post performance
  - Analyze engagement metrics
  - Visualize data with charts

- **Settings**
  - Configure site settings
  - Manage social media accounts
  - SEO optimization
  - Advanced configuration options

## Installation

1. Make sure you have Node.js installed (v14+ recommended)
2. Install dependencies:
   ```
   npm install
   ```
3. Configure environment variables (create a `.env` file):
   ```
   PORT=3000
   WEBSITE_URL=https://liquetax.com
   ```
4. Start the server:
   ```
   npm start
   ```

## Development

For development with auto-restart:
```
npm run dev
```

## Scripts

- `npm start` - Start the server
- `npm run dev` - Start the server with nodemon for development
- `npm run update-blogs` - Update the main index.html with recent blog posts
- `npm run sync-dashboard` - Sync the dashboard with the blog system

## Directory Structure

- `/public` - Static files and client-side assets
- `/scripts` - Utility scripts for maintenance tasks
- `/blog-detaile` - Blog content and templates (in parent directory)

## API Endpoints

### Blog Posts

- `GET /api/blog/posts` - Get all blog posts
- `GET /api/blog/posts/recent` - Get recent blog posts
- `POST /api/blog/posts` - Create a new blog post
- `PUT /api/blog/posts/:id` - Update an existing blog post
- `DELETE /api/blog/posts/:id` - Delete a blog post

### Social Media

- `POST /api/social/publish/:platform/:postId` - Publish a post to social media

### Analytics

- `GET /api/stats` - Get dashboard statistics

## Configuration

Edit the `config.js` file to customize dashboard settings:

```javascript
module.exports = {
    blog: {
        postsPerPage: 10,
        // ...
    },
    // ...
};
```

## Social Media Integration

To enable social media sharing, add your API credentials to the `.env` file or directly in the `config.js` file:

```
TWITTER_API_KEY=your_api_key
TWITTER_API_SECRET=your_api_secret
// ...
```

## Troubleshooting

If you encounter issues:

1. Check the server logs for errors
2. Verify that all dependencies are installed
3. Ensure the blog-detaile directory exists and has proper permissions
4. Make sure Python is installed for blog manager script execution

## License

Copyright © 2024 Liquetax. All rights reserved.# Liquetax Dashboard

A modern, feature-rich dashboard for managing blog content and social media integration for Liquetax.

## Features

- **Blog Management**
  - Create, edit, and delete blog posts
  - Rich text editor with formatting options
  - Featured image upload
  - Category and tag management
  - Draft and scheduled posts
  - Post preview

- **Social Media Integration**
  - Share posts to Twitter, Facebook, and LinkedIn
  - Customize social media messages
  - Schedule social media posts
  - Social media preview

- **Analytics**
  - View traffic statistics
  - Track post performance
  - Analyze engagement metrics
  - Visualize data with charts

- **Settings**
  - Configure site settings
  - Manage social media accounts
  - SEO optimization
  - Advanced configuration options

## Installation

1. Make sure you have Node.js installed (v14+ recommended)
2. Install dependencies:
   ```
   npm install
   ```
3. Configure environment variables (create a `.env` file):
   ```
   PORT=3000
   WEBSITE_URL=https://liquetax.com
   ```
4. Start the server:
   ```
   npm start
   ```

## Development

For development with auto-restart:
```
npm run dev
```

## Scripts

- `npm start` - Start the server
- `npm run dev` - Start the server with nodemon for development
- `npm run update-blogs` - Update the main index.html with recent blog posts
- `npm run sync-dashboard` - Sync the dashboard with the blog system

## Directory Structure

- `/public` - Static files and client-side assets
- `/scripts` - Utility scripts for maintenance tasks
- `/blog-detaile` - Blog content and templates (in parent directory)

## API Endpoints

### Blog Posts

- `GET /api/blog/posts` - Get all blog posts
- `GET /api/blog/posts/recent` - Get recent blog posts
- `POST /api/blog/posts` - Create a new blog post
- `PUT /api/blog/posts/:id` - Update an existing blog post
- `DELETE /api/blog/posts/:id` - Delete a blog post

### Social Media

- `POST /api/social/publish/:platform/:postId` - Publish a post to social media

### Analytics

- `GET /api/stats` - Get dashboard statistics

## Configuration

Edit the `config.js` file to customize dashboard settings:

```javascript
module.exports = {
    blog: {
        postsPerPage: 10,
        // ...
    },
    // ...
};
```

## Social Media Integration

To enable social media sharing, add your API credentials to the `.env` file or directly in the `config.js` file:

```
TWITTER_API_KEY=your_api_key
TWITTER_API_SECRET=your_api_secret
// ...
```

## Troubleshooting

If you encounter issues:

1. Check the server logs for errors
2. Verify that all dependencies are installed
3. Ensure the blog-detaile directory exists and has proper permissions
4. Make sure Python is installed for blog manager script execution

## License

Copyright © 2024 Liquetax. All rights reserved.#   l i q u e t a x  
 